package test;

public class JunitTesting {

}
