package test;

public class JunitTesting extends TestCase
{
	// Test Number 1
	// Test objective Test to see if numbers can be added together?
	//Test input(s): Any integers
	// Test expected output(s): Whatever integers that were entered
	public void testadd3ints001()
	{
		assertEquals("1", add3ints);
	}
	
	// Test Number: 2
	// Test objective: Test to see if negative numbers can be added together?
	// Test input(s): any negative integers
	// Test expected output(s): Whatever integers that were entered
	
	public void testadd3ints002()
	{
		assertequals("-1", add3ints);
	}
	
	// Test number: 6
	// Test objective: Test to get an error
	// Test input(s): A
	// Test expected output(s): Error?
	
	public void testadd3ints002()
	{
		assertequals("A", add3ints);
	}
}
