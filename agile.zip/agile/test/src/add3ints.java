
public class add3ints 
	{
		public static int addThreeInts (int numb1 int num2 int num3)
		{
			throw new RuntimeException("No Product Code Written");
		}
	}

