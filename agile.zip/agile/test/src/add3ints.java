import java.util.Scanner;
public class add3ints {
	
class add3ints{
	
	public static void main(String[] args) {
		int num1, num2, num3, result;
		System.out.println()
	}
		

	}

}
