
public class test {

	public static int absval(int a)

	{

	   if (a < 0)

	   {

	      return -a;

	   }

	   else

	   {

	      return a;

	   }

	}

	public static void main(String[] args)

	{

	   System.out.println(absval(-2));  
}
}